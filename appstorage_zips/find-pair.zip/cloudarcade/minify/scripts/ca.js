var GameAPI=null;"undefined"!=typeof ca_api&&(GameAPI=ca_api);var CA={submit_score:function(a){GameAPI&&GameAPI.submit_score(a).then(function(a){})}};
