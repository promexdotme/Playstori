{
	"level_unlock" : 1,
	"level_totals" : 80,
	"coins" : 200,
	"cost_hint" : 50,
	"coins_bonus" : 15
}