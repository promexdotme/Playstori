
----------------------------------------------
	Thank you for your purchase!	
	If you liked it, please rate.
	Your opinion is very important.
----------------------------------------------

If you have any questions or need a freelance work, please contact me:

Website: https://codecanyon.net/user/trezegames
Or email: trezegamesbr@gmail.com


WARNING:
If you did not purchase this item from the CodeCanyon website, it is recommended to delete it immediately.

Be aware of the risk to your device when downloading content from pirated websites.