function submit_score(a){"undefined"!=typeof ca_api&&ca_api.submit_score(a)}function show_ad(){"undefined"!=typeof ca_api&&ca_api.show_ad()};
