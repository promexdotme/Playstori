var q = [
	{
		q: 'Test',
		a: 'Test',
	},
	{
		q: 'Which fictional city is the home of Batman?',
		a: 'Gotham City',
	},
	{
		q: 'The most popular search engine',
		a: 'Google',
	},
	{
		q: 'Most popular video straming site.',
		a: 'youtube',
	},
	{
		q: 'Most popular smartphone OS.',
		a: 'android',
	},
	{
		q: 'Who is the world’s largest land animal?',
		a: 'Elephant',
	},
	{
		q: 'A yellow fruit?',
		a: 'Banana',
	},
	{
		q: 'Creatures that lived millions of years ago?',
		a: 'Dinosaur',
	},
	{
		q: 'The color of grass?',
		a: 'Green',
	},
];
console.log('total '+q.length);