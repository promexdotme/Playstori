// Used to store global functions and variable


var gameMode = 'normal';
var storageKey = 'rf.four-color';
loadData();
function loadData() {
    let localData = getData(storageKey);
    if (localData) { // Load existing game data
        
    }
}