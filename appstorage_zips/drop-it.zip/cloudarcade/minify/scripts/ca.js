var GameAPI=null;"undefined"!=typeof CA_API&&(GameAPI=new CA_API);var CA={submit_score:function(a){GameAPI&&GameAPI.submit_score(a).then(function(a){})}};
